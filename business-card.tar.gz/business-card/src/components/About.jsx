import React from 'react'

const About = () => {
  return (
    <div className='About'>
      <h4>About</h4>
      <p>The sky was a brilliant shade of blue as the sun slowly descended below the horizon. The air was filled with the scent of blooming flowers and freshly cut grass.</p>
    </div>
  )
}

export default About