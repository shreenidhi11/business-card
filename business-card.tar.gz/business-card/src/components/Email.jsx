import React from 'react'

const Email = () => {
  return (
    <div className='buttons'>
      <button id ="emailbutton" className='btn btn-info'>Email</button>
      <button id="linkedInbutton" className='btn btn-info'>Linkedln</button>
      </div>
  )
}

export default Email