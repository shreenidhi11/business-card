import React from 'react'

const Details = () => {
  return (
    <div className='details'><h2>Shreenidhi Acharya</h2>
    <h3>Front-end Developer</h3>
    <h4>sa8267@rit.edu</h4>
    </div>
  )
}

export default Details