import React from 'react'

const Interest = () => {
  return (
    <div className='Interest'>
      <h4>Interest</h4>
      <p>I took a deep breath, filling my lungs with the crisp, fresh air. I closed my eyes and allowed myself to be fully present in the moment, savoring every sensation.</p>
    </div>
  )
}

export default Interest