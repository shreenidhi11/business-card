import React from 'react'
import img from "../assets/IMG_3012.png";

const Image = () => {
  return (
        <div className='image'>
        <img className='imgprops' src={img} />
        </div>
  )
}

export default Image